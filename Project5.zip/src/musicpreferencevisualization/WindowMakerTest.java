package musicpreferencevisualization;

import student.TestCase;

public class WindowMakerTest extends TestCase {

}
