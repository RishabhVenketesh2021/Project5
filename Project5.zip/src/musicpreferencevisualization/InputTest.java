package musicpreferencevisualization;

public class InputTest {

}
