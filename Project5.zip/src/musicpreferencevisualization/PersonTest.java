package musicpreferencevisualization;

import student.TestCase;

public class PersonTest extends TestCase {

}
