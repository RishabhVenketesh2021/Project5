package musicpreferencevisualization;

import student.TestCase;

public class VisualWindowTest extends TestCase {

}
