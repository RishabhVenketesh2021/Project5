package musicpreferencevisualization;

import student.TestCase;

public class DataCollectorTest extends TestCase {

}
