package musicpreferencevisualization;

import student.TestCase;

public class MajorTest extends TestCase{

}
