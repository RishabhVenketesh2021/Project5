package musicpreferencevisualization;

import java.awt.Color;
import CS2114.Window;
import CS2114.Button;
import CS2114.Shape;
import CS2114.WindowSide;

public class WindowMaker {

    
    private Window window;
    private Shape shape;
    private Button prev;
    private Button sortArtist;
    private Button sortName;
    private Button sortYear;
    private Button sortGenre;
    private Button next;
    private Button repHobby;
    private Button repMajor;
    private Button repRegion;
    
    
}
