package musicpreferencevisualization;

public class Input {
    public static void main(String[] args) {
        VisualWindow run = new VisualWindow("SongListTest1.csv", "MusicSurveyDataTest1.csv");
        
    }
}
